#include "HBRIDGE.h"
#include "Arduino.h"

HBRIDGE::HBRIDGE(int a,int b,int pwm){
pinMode(a,OUTPUT);
a_=a;
pinMode(b,OUTPUT);
b_=b;
pinMode(pwm,OUTPUT);
pwm_=pwm;
}
    void HBRIDGE::MoveRight(int speed){
    digitalWrite(a_,HIGH);
    digitalWrite(b_,LOW);
    analogWrite(pwm_,speed);
    }
    void HBRIDGE::MoveLeft(int speed){
    digitalWrite(a_,LOW);
    digitalWrite(b_,HIGH);
    analogWrite(pwm_,speed);
    }
    void HBRIDGE::Stop(){
    analogWrite(pwm_,0);
    digitalWrite(a_,LOW);
    digitalWrite(b_,LOW);
    }
    void HBRIDGE::FastStop(){
    analogWrite(pwm_,255);
    digitalWrite(a_,HIGH);
    digitalWrite(b_,HIGH);
    }
