#include "HBRIDGE.h"
#include "Arduino.h"

HBRIDGE::HBRIDGE(int a,int b,int pwm){
pinMode(a,OUTPUT);
a_=a;
pinMode(b,OUTPUT);
b_=b;
pinMode(pwm,OUTPUT);
pwm_=pwm;
PWM = true;
}

HBRIDGE::HBRIDGE(int a, int b){
a_ = a;
b_ = b;
pinMode(a_, OUTPUT);
pinMode(b_, OUTPUT);
PWM = false;
}

void HBRIDGE::MoveRight(int speed){
    if(PWM){
       digitalWrite(a_,HIGH);
       digitalWrite(b_,LOW);
       analogWrite(pwm_, max(0, min(255, speed)));
    }
}
void HBRIDGE::MoveLeft(int speed){
    if(PWM){
       digitalWrite(a_,LOW);
       digitalWrite(b_,HIGH);
       analogWrite(pwm_,max(0, min(255, speed)));
    }
}
void HBRIDGE::MoveLeft(){
    digitalWrite(a_,LOW);
    digitalWrite(b_,HIGH);
    if(PWM) analogWrite(pwm_, 255);
}
void HBRIDGE::MoveRight(){
    digitalWrite(b_,LOW);
    digitalWrite(a_,HIGH);
    if(PWM) analogWrite(pwm_, 255);
}
void HBRIDGE::Move(int speed){
    if(PWM){
       if(speed > 0){
          digitalWrite(a_,HIGH);
          digitalWrite(b_,LOW);
          analogWrite(pwm_, max(0, min(255, speed)));
       }else if(speed < 0){
          digitalWrite(a_,LOW);
          digitalWrite(b_,HIGH);
          analogWrite(pwm_, max(0, min(255, abs(speed))));
       }else Stop();
    }
}
void HBRIDGE::Stop(){
    if(PWM) analogWrite(pwm_,0);
    digitalWrite(a_,LOW);
    digitalWrite(b_,LOW);
}
void HBRIDGE::FastStop(){
    if(PWM) analogWrite(pwm_,255);
    digitalWrite(a_,HIGH);
    digitalWrite(b_,HIGH);
}
