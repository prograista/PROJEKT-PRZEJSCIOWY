#include <HBRIDGE.h>

HBRIDGE m1(2,3,4);

void setup() {
  // put your setup code here, to run once:
}

void loop() {
  m1.MoveLeft(100);
  delay(1000);
  m1.FastStop();
  delay(2000);
  m1.MoveRight(255);
  delay(1000);
  m1.FastStop();
  delay(2000);
  // put your main code here, to run repeatedly:

}
