#include <HBRIDGE.h>
//dodanie dwóch silników podłączonych do arduno poprzez sterownik np. L298n
//HBRIDGE <nazwa silnika>(pin odpowiedzialny za obrót w prawo,pin odpowiedzialny za obrót w lewo,pin odpowiedzialny za prędkość obrotu silnika)
HBRIDGE m1(2,3,4);
HBRIDGE m2(5,6,7);

void setup() {
  // put your setup code here, to run once:
}

void loop() {
  // put your main code here, to run repeatedly:
m1.MoveRight(155);
m2.MoveLeft(155);
delay(1500);
m1.Stop();
m2.Stop();
delay(100);
m1.MoveLeft(200);
m2.MoveRight(200);
delay(1000);
m1.FastStop();
m2.FastStop();
delay(100);
}
