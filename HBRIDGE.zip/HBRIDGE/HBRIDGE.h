#ifndef HBRIDGE_h
#define HBRIDGE_h

#include "Arduino.h"

class HBRIDGE{
public:
    HBRIDGE(int a, int b, int pwm);
    HBRIDGE(int a, int b);
    void MoveRight(int speed);
    void MoveLeft(int speed);
    void MoveRight();
    void MoveLeft();
    void Move(int speed);
    void Stop();
    void FastStop();

private:
    int a_;
    int b_;
    int pwm_;
    bool PWM;
};


#endif // HBRIDGE_H_INCLUDED
