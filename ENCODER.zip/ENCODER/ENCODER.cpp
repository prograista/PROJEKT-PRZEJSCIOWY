#include "Arduino.h"
#include "esp32-hal-gpio.h"
#include "ENCODER.h"
ENCODER::ENCODER(int _pinA, int _pinB){
  pinA = _pinA;
  pinB = _pinB;
}

void ENCODER::begin(){
  pinMode(pinA, INPUT_PULLUP);
  pinMode(pinB, INPUT_PULLUP);
  active = 1;
};

void ENCODER::count(){
  if(digitalRead(pinA) == digitalRead(pinB)) pos++;
  else pos--;
}

int64_t ENCODER::getPos(){
  if(active) return pos;
  else return 0;
}