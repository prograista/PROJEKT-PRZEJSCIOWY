#include "Arduino.h"
#ifndef ENCODER_h
#define ENCODER_h

class ENCODER{
  public:
    ENCODER(int _pinA, int _pinB);
    void begin();
    int64_t getPos();
    void count();
  private:
    int pinA, pinB;
    int64_t pos;
    bool active = 0;
};
#endif